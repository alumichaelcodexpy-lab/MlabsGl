package com.mycompany.myapp; // Declares the package for this utility class.

import android.graphics.Bitmap; // Represents bitmap images used for textures.
import android.graphics.Canvas; // Lets us draw shapes onto a bitmap.
import android.graphics.Color; // Provides color helper methods.
import android.graphics.Paint; // Controls how shapes are drawn.

public class TextureUtil { // Utility class for generating fallback textures.

    public static Bitmap makeCheckerBitmap() { // Creates a checkerboard bitmap for fallback rendering.
        Bitmap bmp = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888); // Creates a 256x256 bitmap with alpha support.
        Canvas canvas = new Canvas(bmp); // Wraps the bitmap so we can draw on it.
        Paint paint = new Paint(); // Paint object used to choose colors for the squares.

        int cell = 32; // Size of each checker cell in pixels.
        for (int y = 0; y < 8; y++) { // Loop through 8 rows.
            for (int x = 0; x < 8; x++) { // Loop through 8 columns.
                boolean dark = ((x + y) % 2 == 0); // Alternate dark and light squares.
                paint.setColor(dark ? Color.rgb(70, 70, 70) : Color.rgb(220, 220, 220)); // Pick the color for this square.
                canvas.drawRect(x * cell, y * cell, (x + 1) * cell, (y + 1) * cell, paint); // Draw the square.
            }
        }

        return bmp; // Return the finished checkerboard bitmap.
    }
}
